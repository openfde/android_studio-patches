package mock_android.view;

class LibLoader {
    static {
        System.loadLibrary("dummy");
    }
}