package mock_android.util;

public class NotNeeded {
}