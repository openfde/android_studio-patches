/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.view;

/**
 * Accessor to allow layoutlib to call {@link ViewRootImpl} methods directly.
 */
public class ViewRootImpl_Accessor {
    public static void dispatchApplyInsets(ViewRootImpl viewRoot, View host) {
        viewRoot.dispatchApplyInsets(host);
    }

    public static void setChild(ViewRootImpl viewRoot, View child) {
        viewRoot.mView = child;
        if (child != null) {
            viewRoot.mWidth = child.getWidth();
            viewRoot.mHeight = child.getHeight();
        } else {
            viewRoot.mWidth = -1;
            viewRoot.mHeight = -1;
        }
    }

    public static void detachFromWindow(ViewRootImpl viewRoot) {
        viewRoot.mAccessibilityInteractionConnectionManager.ensureNoConnection();
        viewRoot.mAccessibilityInteractionConnectionManager.ensureNoDirectConnection();
    }
}
