/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.layoutlib.bridge.android;

import com.android.ide.common.rendering.api.IImageFactory;
import com.android.ide.common.rendering.api.RenderParams;
import com.android.ide.common.rendering.api.SessionParams.Key;

/**
 * This contains all known keys for the {@link RenderParams#getFlag(Key)}.
 * <p/>
 * The IDE has its own copy of this class which may be newer or older than this one.
 * <p/>
 * Constants should never be modified or removed from this class.
 */
public final class RenderParamsFlags {

    public static final Key<String> FLAG_KEY_ROOT_TAG = new Key<>("rootTag", String.class);
    public static final Key<Boolean> FLAG_KEY_DISABLE_BITMAP_CACHING =
            new Key<>("disableBitmapCaching", Boolean.class);
    public static final Key<Boolean> FLAG_KEY_RENDER_ALL_DRAWABLE_STATES =
            new Key<>("renderAllDrawableStates", Boolean.class);

    /**
     * To tell LayoutLib to not render when creating a new session. This allows controlling when the first
     * layout rendering will happen.
     */
    public static final Key<Boolean> FLAG_DO_NOT_RENDER_ON_CREATE =
            new Key<>("doNotRenderOnCreate", Boolean.class);
    /**
     * To tell Layoutlib which path to use for the adaptive icon mask.
     */
    public static final Key<String> FLAG_KEY_ADAPTIVE_ICON_MASK_PATH =
            new Key<>("adaptiveIconMaskPath", String.class);

    /**
     * When enabled, Layoutlib will resize the output image to whatever size
     * is returned by {@link IImageFactory#getImage(int, int)}. The default
     * behaviour when this is false is to crop the image to the size of the image
     * returned by {@link IImageFactory#getImage(int, int)}.
     */
    public static final Key<Boolean> FLAG_KEY_RESULT_IMAGE_AUTO_SCALE =
            new Key<>("enableResultImageAutoScale", Boolean.class);

    /**
     * To tell Layoutlib the path of the image resource of the wallpaper to use for dynamic theming.
     * If null, use default system colors.
     */
    public static final Key<String> FLAG_KEY_WALLPAPER_PATH =
            new Key<>("wallpaperPath", String.class);

    /**
     * To tell Layoutlib to use the themed version of adaptive icons.
     */
    public static final Key<Boolean> FLAG_KEY_USE_THEMED_ICON =
            new Key<>("useThemedIcon", Boolean.class);

    /**
     * To tell Layoutlib to automatically create a monochrome version of adaptive icons
     * if one is not explicitly provided.
     */
    public static final Key<Boolean> FLAG_KEY_FORCE_MONOCHROME_ICON =
            new Key<>("forceMonochromeIcon", Boolean.class);

    /**
     * To tell Layoutlib to use the gesture navigation, instead of a button navigation bar.
     */
    public static final Key<Boolean> FLAG_KEY_USE_GESTURE_NAV =
            new Key<>("useGestureNav", Boolean.class);

    /**
     * To tell Layoutlib to display the app edge to edge.
     */
    public static final Key<Boolean> FLAG_KEY_EDGE_TO_EDGE =
            new Key<>("edgeToEdge", Boolean.class);

    /**
     * To tell Layoutlib to display the device cutout if there is one.
     */
    public static final Key<Boolean> FLAG_KEY_SHOW_CUTOUT =
            new Key<>("showCutout", Boolean.class);

    /**
     * To tell Layoutlib whether to cache bitmaps.
     */
    public static final Key<Boolean> FLAG_KEY_CACHE_BITMAPS =
            new Key<>("cacheBitmaps", Boolean.class);

    // Disallow instances.
    private RenderParamsFlags() {}
}
