/**
 * This package contains custom widgets used to set a specific time for the DayTimePicker during
 * testing.
 * The classes here are both used from the Android project and from the Bridge test project.
 */
package com.android.layoutlib.test.myapplication.widgets;